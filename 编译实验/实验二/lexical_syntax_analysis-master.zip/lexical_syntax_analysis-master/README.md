# lexical_syntax_analysis
编译原理词法分析器&amp;语法分析器LR(1)
计算机本科编译原理课程设计，包含词法分析器，LR(1)语法分析器
功能完整，有注释。
